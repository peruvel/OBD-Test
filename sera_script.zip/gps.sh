#!/bin/sh
while [ 1 ];
do
echo "GPS!!!!!!!!!!!!!!!!!!!!!!!!!!"
cat  /dev/ttymxc2 &
sleep 3
killall cat
done
