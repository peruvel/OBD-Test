/home/root/example -token aeu2IC0knkmvwWCvvXUYJQ -test online -p /dev/ttymxc2 -b 9600 -gnss gps/glo
