#echo on > /sys/devices/platform/soc/2100000.aips-bus/2184200.usb/ci_hdrc.1/usb2/power/control
echo 77 > /sys/class/gpio/export
echo 90 > /sys/class/gpio/export
echo 91 > /sys/class/gpio/export
echo 92 > /sys/class/gpio/export
echo 78 > /sys/class/gpio/export
echo 32 > /sys/class/gpio/export
echo 47 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio77/direction
echo out > /sys/class/gpio/gpio90/direction
echo out > /sys/class/gpio/gpio91/direction
echo out > /sys/class/gpio/gpio92/direction
echo out > /sys/class/gpio/gpio78/direction
echo out > /sys/class/gpio/gpio32/direction
echo out > /sys/class/gpio/gpio47/direction

