#!/bin/sh

/home/root/switch_on.sh
/home/root/3g_on.sh
/home/root/3g_ping.sh &
/home/root/gps.sh &
/home/root/acc &
/home/root/gyro &
/home/root/led.sh &
