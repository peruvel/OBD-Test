#!/bin/bash
HOSTIP=`ifconfig ppp0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
echo "$HOSTIP"
while [ 1 ];
do
	if ping -q -c 1 -W 1 google.com >/dev/null; 
	then
	  break
	else
	  echo "2g Connection is down"
	  pppd call gprs_4g
	  sleep 1
	fi
done

ping google.com
