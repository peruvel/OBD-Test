echo 78 > /sys/class/gpio/export
echo 47 > /sys/class/gpio/export           
echo out > /sys/class/gpio/gpio78/direction
echo out > /sys/class/gpio/gpio47/direction

#Turn on usb switch                        
                                           
echo 1 > /sys/class/gpio/gpio78/value
#Turn on 3g                          
echo 0 > /sys/class/gpio/gpio47/value
usleep 200000                        
echo 1 > /sys/class/gpio/gpio47/value
usleep 600000                        
echo 0 > /sys/class/gpio/gpio47/value
sleep 2                              
#enable USB driver enable
insmod /usb/udc-core.ko              
insmod /usb/libcomposite.ko
insmod /usb/ci_hdrc.ko     
insmod /usb/usbmisc_imx.ko 
insmod /usb/ci_hdrc_imx.ko
insmod /usb/u_serial.ko   
insmod /usb/usb_f_serial.ko
insmod /usb/usb_f_acm.ko   
insmod /usb/g_serial.ko 

sleep 2

