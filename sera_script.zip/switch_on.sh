echo 90 > /sys/class/gpio/export
echo 91 > /sys/class/gpio/export
echo 92 > /sys/class/gpio/export
echo 77 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio90/direction
echo out > /sys/class/gpio/gpio91/direction
echo out > /sys/class/gpio/gpio92/direction
echo out > /sys/class/gpio/gpio77/direction
i2cset -f -y 0 0x6b 0x00 0x17
i2cset -f -y 0 0x6b 0x02 0x82
i2cset -f -y 0 0x6b 0x03 0x11
i2cset -f -y 0 0x6b 0x05 0x8f
echo 1 > /sys/class/gpio/gpio90/value
echo 1 > /sys/class/gpio/gpio91/value
echo 1 > /sys/class/gpio/gpio92/value
#echo 1 > /sys/class/gpio/gpio32/value
#echo 1 > /sys/class/gpio/gpio78/value
